package edu.ucam.acciones;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Clase que permite obtener la ruta de la jsp para eliminar productos
 * @author Alejandro
 *
 */
public class AccionIrEliminarProducto extends Accion{
/**
 * Metodo que retorna la ruta de acceso a la jsp
 * @return ruta jsp "eliminarProducto"
 */
	@Override
	public String ejecutar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		return "eliminarProducto.jsp";
	}

}
