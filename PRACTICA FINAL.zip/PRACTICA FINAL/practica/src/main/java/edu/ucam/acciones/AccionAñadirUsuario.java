package edu.ucam.acciones;

import java.io.IOException;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ucam.pojos.Usuario;
/**
 * Clase que permite a�adir un usuario a la tabla hash de usuarios, que posteriormente se volcar� en la base de datos
 * @author Alejandro
 *
 */
public class AccionA�adirUsuario extends Accion {
/**
 * Metodo para a�adir usuario mediante los parametros recogidos en el formulario de la jsp "a�adirUsuario"
 * @return ruta al menu del administrador
 */
	@Override
	public String ejecutar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String nombre= (String) request.getParameter("NAME"); //variable que recoge el nombre del nuevo usuario
		String contrase�a = (String) request.getParameter("PASS");//variable que recoge la contrase�a del nuevo usuario
		Usuario user= new Usuario(nombre,contrase�a); //instancia de objeto Usuario
		
		Hashtable<String, Usuario> usuarios= (Hashtable<String, Usuario>) request.getServletContext().getAttribute("USUARIOS"); //se obtiene la tabla hash del contexto para ser usada en esta clase
		
		//si en la tabla de usuarios no existe un usuario con dicha contrase�a, se procede al almacenamiento de este nuevo usuario
		if (!usuarios.containsKey(user.getPass())) {
			
			usuarios.put(user.getPass(), user); //se vuelca en al tabla hash
			request.getSession().setAttribute("MENSAJE", "Usuario a�adido"); 
			
			return "menuAdministrador.jsp";
		}else {
			request.getSession().setAttribute("MENSAJE", "Usuario ya existente");
			return "menuAdministrador.jsp";
		}
	}

}
