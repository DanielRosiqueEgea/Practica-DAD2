package edu.ucam.acciones;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Clase que permite obtener la ruta de acceso de la jsp para eliminar usuarios
 * @author Alejandro
 *
 */
public class AccionIrEliminarUsuario extends Accion{
/**
 * Metodo para obtener la ruta de la jsp
 * @return ruta jsp "eliminarUsuario"
 */
	@Override
	public String ejecutar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			return "eliminarUsuario.jsp";
	}

}
