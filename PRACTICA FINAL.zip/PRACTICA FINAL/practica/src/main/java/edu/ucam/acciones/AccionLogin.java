package edu.ucam.acciones;

import java.io.IOException;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ucam.pojos.Usuario;
/**
 * Clase para realizar el login en la pagina web
 * @author Alejandro
 *
 */
public class AccionLogin extends Accion {
/**
 * Metodo que permite hacer el login del administrador y de los usuarios
 * @return ruta de la jsp "menuAdministrado"
 * @return ruta de la jsp "login"
 */
	@Override
	public String ejecutar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String nombre= request.getParameter("NAME"); //nombre recoge el valor del parametro NAME que hemos metido en la jsp login
		String pass= request.getParameter("PASS");//pass recoge el valor del parametro PASS que hemos metido en la jsp login
		Usuario user= new Usuario(nombre,pass);
		
		Hashtable<String, Usuario> usuarios = (Hashtable<String, Usuario>) request.getServletContext().getAttribute("USUARIOS");
		
		if ("admin".equals(user.getPass()) && "admin".equals(user.getNombre())) { //esto lo hago asi porque quiero que el administrador pueda acceder a su entorno siempre, asegurandome que niongun fallo en el programa pueda evitarselo
			request.getSession().setAttribute("USUARIO", user);
			return "menuAdministrador.jsp";
			
		}else {
			if(usuarios.containsKey(user.getPass()) && usuarios.get(user.getPass()).getNombre().equals(user.getNombre())) {
			request.getSession().setAttribute("USUARIO", user);
			System.out.println(request.getSession().getAttribute("USUARIO"));
			return "menuProductos.jsp";
		}return "login.jsp";
		
		}
		
		
	}

}
