package edu.ucam.acciones;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Clase que permitir� dirigir al administrador a la pesta�a de A�adir usuario
 * @author Alejandro
 *
 */
public class AccionIrA�adirUsuario extends Accion {

	/**
	 * @return ruta a la jsp de a�adir usuario
	 */
	@Override
	public String ejecutar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			return "a�adirUsuario.jsp";
	}

}
