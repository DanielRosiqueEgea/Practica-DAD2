package edu.ucam.acciones;

import java.io.IOException;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ucam.pojos.Usuario;
/**
 * Clase que permite la eliminacion de un usuario por parte del administrador
 * @author Alejandro
 *
 */
public class AccionEliminarUsuario extends Accion {

	/**
	 * Metodo para eliminar un usuario de la tabla hash de usuarios
	 * @return ruta al menu del administrador
	 */
	@Override
	public String ejecutar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String nombre= (String) request.getParameter("NAME");
		String contrase�a = (String) request.getParameter("PASS");
		Usuario user= new Usuario(nombre,contrase�a);
		
		Hashtable<String, Usuario> usuarios= (Hashtable<String, Usuario>) request.getServletContext().getAttribute("USUARIOS");
		
		//si en la tabla hash existe un usuario con esa misma contrase�a, se procede a su eliminacion
		if (usuarios.containsKey(user.getPass())) {
			
			usuarios.remove(user.getPass());
			request.getSession().setAttribute("MENSAJE", "Usuario eliminado");
			
			return "menuAdministrador.jsp";
		}else {
			request.getSession().setAttribute("MENSAJE", "Usuario no existente");
			return "menuAdministrador.jsp";
		}
	}

}
