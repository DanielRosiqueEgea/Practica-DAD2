package edu.ucam.acciones;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Clase que permite ir a la jsp de a�adir productos
 * @author Alejandro
 *
 */
public class AccionIrA�adirProducto extends Accion {
/**
 * Metodo que retorna la ruta de acceso a la jsp para a�adir productos
 * @return ruta de jsp "a�adirProdcutos"
 */
	@Override
	public String ejecutar(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		return "a�adirProductos.jsp";
	}

}
